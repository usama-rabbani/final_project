import React from 'react'

function Createproduct() {
  return (
    <div>
      Manage Category
      </div>
  )
}

export default Createproduct