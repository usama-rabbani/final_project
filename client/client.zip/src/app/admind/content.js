// 'use client'
// import React from 'react'

// import Dashboard from './dashboard'
// import { useauth } from '../../context/auth'

// function Content() {
//     const { auth, setAuth } = useauth();
//   return (
//     <div className='flex items-center justify-evenly'>
// <div>
//     <Dashboard/>
// </div>


// <div>
// <div className='border border-2 py-4 pr-24'>
// <h1>Admin Name: {auth?.user?.name}</h1>
// <h1>Admin Email: {auth?.user?.email}</h1>
// <h1>Role: {auth?.user?.role}</h1>
// </div>

// </div>
//     </div>
//   )
// }

// export default Content