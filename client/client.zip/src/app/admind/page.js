import React from 'react'

import Dashboard from './dashboard'
function AdminD() {
  return (
  <main className='px-24 jitems-center'>
    <Dashboard/>
  </main>
  
   
 
  )
}

export default AdminD