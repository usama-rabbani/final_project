import React from 'react'

function Userd() {
  return (
    <div>User Dashboard</div>
  )
}

export default Userd